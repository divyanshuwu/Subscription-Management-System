import { useEffect, useState, type FormEvent } from "react";
import { X, Plus, Trash2 } from "lucide-react";
import { request, money, type Subscription, type Product } from "../data";
export function SubscriptionEditor({
  subscription,
  customer,
  onClose,
  onSaved,
}: {
  subscription: Subscription;
  customer: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [lines, setLines] = useState(
      subscription.pending_lines || subscription.lines,
    ),
    [products, setProducts] = useState<Product[]>([]),
    [search, setSearch] = useState(""),
    [product, setProduct] = useState(""),
    [expiry, setExpiry] = useState(subscription.expiry_date),
    [terms, setTerms] = useState(subscription.payment_terms),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    let cancelled = false;
    const timer = setTimeout(() => {
      void request(
        `${customer ? "/portal/catalog" : "/products"}?search=${encodeURIComponent(search)}&page_size=50`,
      )
        .then((r) => {
          if (!cancelled) setProducts(r.data);
        })
        .catch((e) => {
          if (!cancelled) setError(e.message);
        });
    }, 180);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [customer, search]);
  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await request(
        `${customer ? "/portal" : ""}/subscriptions/${subscription.id}`,
        {
          method: "PUT",
          body: JSON.stringify({
            expected_revision: subscription.revision || 0,
            lines: lines.map((l) => ({
              product_id: l.product_id,
              quantity: l.quantity,
              variant_ids: l.variant_ids || [],
            })),
            ...(!customer ? { expiry_date: expiry, payment_terms: terms } : {}),
          }),
        },
      );
      onSaved();
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to save");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="modal-backdrop">
      <section
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="edit-subscription-title"
      >
        <button
          className="icon-button modal-close"
          aria-label="Close editor"
          onClick={onClose}
        >
          <X size={18} />
        </button>
        <h2 id="edit-subscription-title">Edit subscription</h2>
        <p className="modal-description">
          Changes to active subscriptions apply at the next future billing
          boundary. Issued invoices never change.
        </p>
        <form onSubmit={save}>
          <div className="form-grid">
            {!customer && (
              <>
                <label className="field">
                  <span>Term expires</span>
                  <input
                    aria-label="Term expires"
                    type="date"
                    required
                    value={expiry}
                    onChange={(e) => setExpiry(e.target.value)}
                  />
                </label>
                <label className="field">
                  <span>Payment terms (days)</span>
                  <input
                    aria-label="Payment terms (days)"
                    type="number"
                    min="0"
                    max="365"
                    value={terms}
                    onChange={(e) => setTerms(Number(e.target.value))}
                  />
                </label>
              </>
            )}
          </div>
          {lines.map((l, i) => (
            <div className="detail-line" key={`${l.product_id}-${i}`}>
              <span>
                <strong>{l.name}</strong>
                <small>{money(l.unit_price, 2)} per unit</small>
              </span>
              <label className="field">
                <span>Quantity</span>
                <input
                  aria-label={`Quantity for ${l.name}`}
                  type="number"
                  min="1"
                  max="100000"
                  value={l.quantity}
                  onChange={(e) =>
                    setLines((rows) =>
                      rows.map((r, j) =>
                        j === i
                          ? { ...r, quantity: Number(e.target.value) }
                          : r,
                      ),
                    )
                  }
                />
              </label>
              {i > 0 && (
                <button
                  type="button"
                  className="icon-button"
                  aria-label={`Remove ${l.name}`}
                  onClick={() =>
                    setLines((rows) => rows.filter((_, j) => j !== i))
                  }
                >
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          ))}
          <label className="field">
            <span>Find an add-on</span>
            <input
              aria-label="Search add-ons"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search products…"
            />
          </label>
          <label className="field">
            <span>Add-on product</span>
            <select
              aria-label="Add-on product"
              value={product}
              onChange={(e) => setProduct(e.target.value)}
            >
              <option value="">Select product</option>
              {products
                .filter((p) => !lines.some((l) => l.product_id === p.id))
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} · {money(p.sales_price, 2)}
                  </option>
                ))}
            </select>
          </label>
          <button
            type="button"
            className="button"
            disabled={!product}
            onClick={() => {
              const p = products.find((p) => p.id === product);
              if (p) {
                setLines((rows) => [
                  ...rows,
                  {
                    product_id: p.id,
                    name: p.name,
                    quantity: 1,
                    unit_price: p.sales_price,
                    variant_ids: [],
                  },
                ]);
                setProduct("");
              }
            }}
          >
            <Plus size={16} />
            Add product line
          </button>
          {error && (
            <div className="form-error" role="alert">
              {error}
            </div>
          )}
          <button className="button primary full" disabled={busy}>
            {busy ? "Saving…" : "Save subscription changes"}
          </button>
        </form>
      </section>
    </div>
  );
}
