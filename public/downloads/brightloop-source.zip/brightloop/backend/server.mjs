import "dotenv/config";
import cron from "node-cron";
import { app } from "./app.mjs";
import { migrate, db } from "./db.mjs";
import { secret } from "./auth.mjs";
import { runBilling, refreshSummary, reminders } from "./services.mjs";
secret();
await migrate();
await refreshSummary();
const server = app.listen(Number(process.env.PORT || 4000), "127.0.0.1", () =>
  console.log(
    `Brightloop API listening locally on port ${process.env.PORT || 4000}`,
  ),
);
let running = false;
if (process.env.SCHEDULER !== "off")
  cron.schedule(
    "5 0 * * *",
    async () => {
      if (running) return;
      running = true;
      try {
        await runBilling();
        await reminders();
        await refreshSummary();
      } catch (e) {
        console.error("Scheduled billing failed", e);
      } finally {
        running = false;
      }
    },
    { timezone: "UTC" },
  );
for (const signal of ["SIGINT", "SIGTERM"])
  process.on(signal, () =>
    server.close(async () => {
      await db.destroy();
      process.exit(0);
    }),
  );
